package com.liferay.sales.taxes.domain.model;

import lombok.Data;

@Data
public class GenericResponse {

    private String message;

}
